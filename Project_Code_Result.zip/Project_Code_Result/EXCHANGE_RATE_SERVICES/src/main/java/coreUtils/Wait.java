package coreUtils;

public class Wait {

}
